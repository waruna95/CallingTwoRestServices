package com.waruna.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.waruna.modal.Allocation;

public interface AllocationRepository extends JpaRepository<Allocation, Integer>{
	
	List<Allocation> findByEmpid(Integer id);
	

}

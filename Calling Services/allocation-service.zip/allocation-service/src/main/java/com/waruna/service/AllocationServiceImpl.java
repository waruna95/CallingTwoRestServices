package com.waruna.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.waruna.modal.Allocation;
import com.waruna.repository.AllocationRepository;

@Service
public class AllocationServiceImpl implements AllocationService{

	@Autowired
	AllocationRepository allocationRepository;
	
	
	/* (non-Javadoc)
	 * @see com.waruna.service.AllocationService#save(com.waruna.modal.Allocation)
	 */
	@Override
	public Allocation save(Allocation allocation) {
		
		return allocationRepository.save(allocation);
	}

	/* (non-Javadoc)
	 * @see com.waruna.service.AllocationService#fetchById(java.lang.Integer)
	 */
	@Override
	public Optional<Allocation> fetchById(Integer id) {
		
		return allocationRepository.findById(id);
			
	}
	
	/* (non-Javadoc)
	 * @see com.waruna.service.AllocationService#fetchAll()
	 */
	@Override
	public List<Allocation> fetchAll() {
		return allocationRepository.findAll();
		
	}
	
	@Override
	public List<Allocation> fetchByEmpId(Integer id) {
		return allocationRepository.findByEmpid(id);
		
	}

}

package com.waruna.service;

import java.util.List;
import java.util.Optional;

import com.waruna.modal.Allocation;

public interface AllocationService {

	Allocation save(Allocation allocation);

	Optional<Allocation> fetchById(Integer id);

	List<Allocation> fetchAll();
	
	List<Allocation> fetchByEmpId(Integer id);

}
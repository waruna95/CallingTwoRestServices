package com.example.demo.modal;

import java.util.List;

import javax.persistence.*;

;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id;
	String name;
	
	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
	List<Telephone> telephones;
	
	@ManyToMany(cascade = CascadeType.ALL)
		@JoinTable(name = "employee_project", joinColumns = @JoinColumn(name = "eid", referencedColumnName = "id"),inverseJoinColumns = @JoinColumn(name = "pid",referencedColumnName = "id"))
	List<Project> projects;
	
	public List<Project> getProjects() {
		return projects;
	}
	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}
	@OneToOne(cascade = CascadeType.ALL)
	Address address;

	@Transient//this will not addeed to the DB
	Allocation[] allocations;

	public Allocation[] getAllocations() {
		return allocations;
	}

	public void setAllocations(Allocation[] allocations) {
		this.allocations = allocations;
	}

	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Telephone> getTelephones() {
		return telephones;
	}
	public void setTelephones(List<Telephone> telephones) {
		this.telephones = telephones;
	}
	

}
